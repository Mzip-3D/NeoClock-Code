# SPDX-FileCopyrightText: Parts not copyright Liz Clark are free
# to the world by the author. Code is specific to the Adafruit
# Prop-Maker Feather, DS3231 real time clock, and a 14 neopixel
# string for depicting the time and doing minor animation.

# SPDX-FileCopyrightText: 2023 Liz Clark for Adafruit Industries
# SPDX-License-Identifier: MIT
# Code originally from https://learn.adafruit.com/lightsaber-rp2040

import time
import os
import random
import board
import pwmio
import simpleio
import neopixel
import audiocore
import audiobusio
import audiomixer
import microcontroller
import adafruit_lis3dh
from adafruit_debouncer import Debouncer
from digitalio import DigitalInOut, Direction, Pull  # needed for the peripherals
from ulab import numpy as np

############## USER VARIABLES ##################

ticks = True     # set to False for no tick sound, True for tick sounds
chime = False    # set to False for no chimes, True for chimes
bongs = False    # set to False for no hour bongs, True for hour bongs

volume = 0.1    # volume range is 0.0 (silent) to 1.0 (full volume)

############## USER VARIABLES ##################

TICK = True     # definition to alternate between ticks and tocks (don't touch)
PRESSED = False # definition to use to test if the pushbutton has been pressed
                # when pressed the pin goes low which is a logic False

redval = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]
greenval = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]
blueval = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]

# ###########  ACCELEROMETER VARS  ################################

# CUSTOMIZE TAP SENSITIVITY HERE: smaller numbers = more sensitive
TAP_THRESHOLD = 80
x = y = z = 0.0   # initialize the motion variables

# ########### POWER FOR EXTERNALS ###############################

# enable external power pin
# provides power to the external components
external_power = DigitalInOut(board.EXTERNAL_POWER)
external_power.direction = Direction.OUTPUT
external_power.value = True

# ########### FIND & COUNT  SOUND FILES ###########################

wavs = []
for filename in os.listdir('/sounds'):
    if filename.lower().endswith('.wav') and not filename.startswith('.'):
        wavs.append("/sounds/"+filename)
wavs.sort()
print(wavs)
print(len(wavs))

audio = audiobusio.I2SOut(board.I2S_BIT_CLOCK, board.I2S_WORD_SELECT, board.I2S_DATA)

mixer = audiomixer.Mixer(voice_count=1, sample_rate=22050, channel_count=1,
                         bits_per_sample=16, samples_signed=True)

audio.play(mixer)

def play_wav(num, loop=False):
    """
    Play a WAV file in the 'sounds' directory.
    :param name: partial file name string, complete name will be built around
                 this, e.g. passing 'foo' will play file 'sounds/foo.wav'.
    :param loop: if True, sound will repeat indefinitely (until interrupted
                 by another sound).
    """

    try:
        n = wavs[num]
        wave_file = open(n, "rb")
        wave = audiocore.WaveFile(wave_file)
        mixer.voice[0].play(wave, loop=loop)
    except:  # pylint: disable=bare-except
        return

def wait_quiet():
    while (mixer.playing):
        time.sleep(0.1)       # Do nothing

# ########## INIT PROP-MASTER BUTTON INPUT #######################

# external button
pin = DigitalInOut(board.EXTERNAL_BUTTON)
pin.direction = Direction.INPUT
pin.pull = Pull.UP

# ########### INIT PROP-MASTER ACCELEROMETER ###################

# onboard LIS3DH
i2c = board.I2C()
int1 = DigitalInOut(board.ACCELEROMETER_INTERRUPT)
lis3dh = adafruit_lis3dh.LIS3DH_I2C(i2c, int1=int1)
# Accelerometer Range (can be 2_G, 4_G, 8_G, 16_G)
lis3dh.range = adafruit_lis3dh.RANGE_2_G    # on a 2G range, acceleration idles at
                                            # around 90 units (gravity)
# Taps off to start
lis3dh.set_tap(0, TAP_THRESHOLD)    # This project doesn't use taps

#  - 0 = Disable tap detection.
#  - 1 = Detect single taps.
#  - 2 = Detect double taps.        # Double taps so harder to trigger accidentally

# taps_on and taps_off are used to enable/disable tap interrupts because the
# sounds can trigger false taps. Tap interrupts only on when waiting for taps.

def taps_off():
    lis3dh.set_tap(0, TAP_THRESHOLD)

def taps_on():
    lis3dh.set_tap(2, TAP_THRESHOLD)    #

# #############  NEOPIXEL VARS  #####################################

DARK = (0, 0, 0)    # pixel values are R, G, B on 0-255 scale
RED = (255, 0, 0)
YELLOW = (125, 255, 0)
GREEN = (0, 255, 0)
CYAN = (0, 125, 255)
BLUE = (0, 0, 255)
PURPLE = (125, 0, 255)
WHITE = (255, 255, 255)
COLORS = [DARK, RED, YELLOW, GREEN, CYAN, BLUE, PURPLE, WHITE]

# ########### INIT PROP-MASTER NEOPIX OUTPUT #####################

# external neopixels
num_pixels = 14
pixels = neopixel.NeoPixel(board.EXTERNAL_NEOPIXELS, num_pixels, auto_write=True)

# max neopixel brightness - everything is scaled by this number 0-1
# note - setting brightness higher can draw too much power when all LEDs are on full
pixels.brightness = 1.0

for i in range (0, 12):         # set clock digit pixels dark and the center image pixels to color
    pixels[i] = (DARK)

pixels[12]=(WHITE)
pixels[13]=(WHITE)

# ######################## INIT REAL TIME CLOCK ##########################

import adafruit_ds3231
ds3231 = adafruit_ds3231.DS3231(i2c)
current = ds3231.datetime       # burn one to clear out cruft

# ####################### Clear Clock #############################

def clear_clock():

    global redval
    global greenval
    global blueval

    # set the display all dark
    for i in range (0, num_pixels):         # set all pixels dark
        pixels[i] = (DARK)
        redval[i] = 0
        greenval[i] = 0
        blueval[i] = 0

# ####################### LIGHT HOURS #############################

def light_hours(hours):

    # which pixel to light equals the hours?
    if (hours == 0):
        pixel = 11      # pixel is array element. the array starts at 0 at 1 o'clock
    else:
        pixel = hours - 1  # correct for zero 1st element index - 1 o'clock is [0]

    # turn off the previous hour/red pixel
    if (pixel == 0):
        redval[11] = 0
        pixels[11] = (redval[11], greenval[11], blueval[11])
    else:
        redval[pixel-1] = 0
        pixels[pixel-1] = (redval[pixel-1], greenval[pixel-1], blueval[pixel-1])

    # turn on the current hour pixel
    redval[pixel] = 255
    pixels[pixel] = (redval[pixel], greenval[pixel], blueval[pixel])

# ####################### LIGHT MINUTES ###########################

def light_minutes(minutes):

    virtual_minutes = minutes % 5    # 0-4 minutes added to the base_pixel
    dmins = int (minutes / 5)        # base digit to light 0 indexed - these are 5 minute blocks

#    print("dmins=", dmins, " vmins=", virtual_minutes)

    # Two LEDs can be lit - the base minutes digit and the next one that is growing in as the base dims
    # which digit is the base noting 0 indexed starting at 1 oclock
    if (dmins == 0):
        pixel = 11      # 12 oclock/0 minutes is pixels[11]
    else:
        pixel = dmins - 1

    # do we need to turn off the last led? if virtual_minutes = 0 then yes every 5 minutes
    if (virtual_minutes == 0):
        if (pixel == 0):
            greenval[11] = 0
            pixels[11] = (redval[11], greenval[11], blueval[11])
        else:
            greenval[pixel-1] = 0
            pixels[pixel-1] = (redval[pixel-1], greenval[pixel-1], blueval[pixel-1])

    # the leds ratio intensity between the base led and the next one
    # digit is the lower pixel we turn on and dims as minutes tick, dmins is the upper pixel that loads up as minutes tick

    greenval[pixel] = 51 * (5 - virtual_minutes)
    pixels[pixel] = (redval[pixel], greenval[pixel], blueval[pixel])

    # now set the pixel above that gets brighter as minutes tick by
    if (pixel == 11):
        greenval[0] = 51 * virtual_minutes
        pixels[0] = (redval[0], greenval[0], blueval[0])
    else:
        greenval[pixel+1] = 51 * virtual_minutes
        pixels[pixel+1] = (redval[pixel+1], greenval[pixel+1], blueval[pixel+1])

# ####################### LIGHT SECONDS ###########################

def light_seconds(seconds):

    virtual_seconds = seconds % 5    # 0-4 seconds added to the base_pixel
    dsecs = int (seconds / 5)        # base digit to light 0 indexed - these are 5 second blocks

#    print("dsecs=", dsecs, " vsecs=", virtual_seconds)

    # Two LEDs can be lit - the base seconds digit and the next one that is growing in as the base dims
    # which digit is the base noting 0 indexed starting at 1 oclock
    if (dsecs == 0):
        pixel = 11      # 12 oclock/0 seconds is pixels[11]
    else:
        pixel = dsecs - 1

    # do we need to turn off the last led? if virtual_seconds = 0 then yes every 5 minutes
    if (virtual_seconds == 0):
        if (pixel == 0):
            blueval[11] = 0
            pixels[11] = (redval[11], greenval[11], blueval[11])
        else:
            blueval[pixel-1] = 0
            pixels[pixel-1] = (redval[pixel-1], greenval[pixel-1], blueval[pixel-1])

    # the leds ratio intensity between the base led and the next one
    # digit is the lower pixel we turn on and dims as minutes tick, dmins is the upper pixel that loads up as minutes tick

    blueval[pixel] = 51 * (5 - virtual_seconds)
    pixels[pixel] = (redval[pixel], greenval[pixel], blueval[pixel])

    # now set the pixel above that gets brighter as minutes tick by
    if (pixel == 11):
        blueval[0] = 51 * virtual_seconds
        pixels[0] = (redval[0], greenval[0], blueval[0])
    else:
        blueval[pixel+1] = 51 * virtual_seconds
        pixels[pixel+1] = (redval[pixel+1], greenval[pixel+1], blueval[pixel+1])

# #######################  SET CLOCK  #############################

def set_clock():

    global redval
    global greenval
    global blueval

    clear_clock()

    time.sleep(1)
    hours = 1
    light_hours(hours)

    done = False
    while (done == False):
        for i in range (0, 8):
            time.sleep(0.1)
            switch = Debouncer(pin)
            if (switch.value == PRESSED):
                done = True
                break
        if (done == False):
            hours = hours + 1
            if (hours > 11):
                hours = 0
            light_hours(hours)

    time.sleep(1)

    clear_clock()

    minutes = 0
    light_minutes(minutes)

    done = False
    while (done == False):
        for i in range (0, 5):
            time.sleep(0.1)
            switch = Debouncer(pin)
            if (switch.value == PRESSED):
                done = True
                break
        if (done == False):
            minutes = minutes + 1
            if (minutes > 59):
                minutes = 0
            light_minutes(minutes)

    time.sleep(1)

    clear_clock()

    seconds = 0
    light_seconds(seconds)

    done = False
    while (done == False):
        time.sleep(0.01)
        switch = Debouncer(pin)
        if (switch.value == PRESSED):
            done = True
            break
        if (done == False):
            seconds = seconds + 1
            if (seconds > 59):
                seconds = 0
            light_seconds(seconds)

    # we only set hours and minutes with seconds set to zero to allow precise time setting
    # but you must set year, mon, date, hour, min, sec and weekday all at once to write anything
    # yearday is not supported, isdst can be set but we don't do anything with it at this time

    #                     year, mon, date, hour,   min,   sec, wday, yday, isdst
    t = time.struct_time((2026,  1,   1,  hours, minutes,  0,   0,    0,    0))
    ds3231.datetime = t
    print("Time set to:", t)

    clear_clock()

    pixels[12]=WHITE
    pixels[13]=WHITE

# ######################## MAIN LOOP ##############################

mixer.voice[0].level = volume
soundon = True

while (mixer.playing):      # test to make sure audio isn't busy. It's a problem if it is and will
    print("Waiting")        # hang here if there is an issue with the audio system. More just fyi
    time.sleep(0.1)         # If code works ok then stops here mean a different issue with audio.

hours = 0
minutes = 0
seconds = 0
playing_bongs = False
bongs_played = 0
bongs_to_play = 0

while (True):

    current = ds3231.datetime
    # wait for a second to tick over - that will make datetime change
    while (current == ds3231.datetime):  # can always adjust the time - checks every second
        switch = Debouncer(pin)
        if (switch.value == PRESSED):
            set_clock()
            switch = Debouncer(pin)
            while(switch.value == PRESSED):  # wait for them to let go
                time.sleep(0.2)
                switch = Debouncer(pin)
            # clean up from setting time
            microcontroller.reset()     # easiest way to clean up the display after setting time
                                        # a reset keeps power on to the RTC while clearing the micro
            break
        time.sleep(0.1)

    if ((ticks == True) & (playing_bongs == False)):
        if (mixer.playing == False):
            if (TICK == True):
                play_wav(5, loop=False)
                TICK = False
            else:
                play_wav(6, loop=False)
                TICK = True

    if ((bongs == True) & (playing_bongs == True) & (bongs_played <= bongs_to_play)):
        if (mixer.playing == False):
                play_wav(4, loop=False)
                bongs_played = bongs_played + 1
                if (bongs_played == bongs_to_play):
                    playing_bongs = False
#        print("Bongs played= ", bongs_played, " Bongs to play= ", bongs_to_play)

    hours = current.tm_hour % 12   # clock outputs 24 hour time so convert to 12 hour time
    minutes = current.tm_min
    seconds = current.tm_sec

    light_hours(hours)
    light_minutes(minutes)
    light_seconds(seconds)

#    print("Time: ", hours, ":", minutes, ":", seconds)

    # chime on the quarter hours

    if (seconds == 0):
        wait_quiet()    # let any ticks finish
        if (minutes == 15):
            if (chime == True):
                play_wav(0, loop=False)
        elif (minutes == 30):
            if (chime == True):
                play_wav(1, loop=False)
        elif (minutes == 45):
            if (chime == True):
                play_wav(2, loop=False)
        elif (minutes == 0):
            if (chime == True):
                play_wav(3, loop=False)
            if (bongs == True):
                playing_bongs = True
                if (hours == 0):
                    bongs_to_play = 12
                else:
                    bongs_to_play = hours
                bongs_played = 0
